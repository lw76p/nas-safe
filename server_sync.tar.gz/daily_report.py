"""
NAS Safe — 每日状态日报

每天定时把 NAS 状态（备份、异常、能清理的空间、硬盘状态）发到用户已配置的
微信 / 邮箱 / 群机器人等。完全复用现有通知链路，不需要额外权限。

数据源：
  · 备份情况  → storage 列卷/快照
  · 异常提醒  → anomalies.collect_anomalies
  · 可清空间  → junk.load_report（先扫过才有数字）
  · 硬盘状态  → metrics.collect（温度、用量、多久会满）

推送：复用 notify.dispatch，自动走所有已启用通道。
调度：后台守护线程，按用户设定的时间每天跑一次（默认 08:00）。
"""

from __future__ import annotations

import json
import os
import threading
import time

import storage
import anomalies
import metrics
import junk
import notify
import smartd


# ---------------------------------------------------------------------------
# 配置 / 上次报告持久化（均落 state 目录，绝不进仓库）
# ---------------------------------------------------------------------------

def _path(name: str) -> str:
    return os.path.join(storage.state_dir(), name)


def config_path() -> str:
    return _path("daily_report.json")


def load_config() -> dict:
    try:
        with open(config_path(), "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        cfg = {}
    cfg.setdefault("enabled", False)
    cfg.setdefault("hour", 8)
    cfg.setdefault("minute", 0)
    return cfg


def save_config(cfg: dict) -> None:
    os.makedirs(storage.state_dir(), exist_ok=True)
    with open(config_path(), "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def load_last() -> dict | None:
    try:
        with open(_path("daily_report_last.json"), "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def save_last(report: dict) -> None:
    try:
        with open(_path("daily_report_last.json"), "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# 报告聚合
# ---------------------------------------------------------------------------

def _safe(fn, default):
    try:
        return fn()
    except Exception:  # noqa: BLE001
        return default


def build_report() -> dict:
    """聚合四大维度，返回结构化报告。任一子系统故障不影响整体。"""
    # —— 快照保护 ——
    snap_summary = _safe(_snapshot_summary, None)
    # —— 告警 ——
    alerts = _safe(lambda: anomalies.collect_anomalies(), []) or []
    crit = sum(1 for a in alerts if a.get("sev") == 2)
    warn = sum(1 for a in alerts if a.get("sev") == 1)
    # —— 可释放空间 ——
    freeable = _safe(_freeable_summary, None)
    # —— 硬盘健康 / 容量 ——
    disk = _safe(_disk_summary, None)
    # —— SMART 健康（可用才采，跨品牌；取不到优雅降级）——
    smart = _safe(lambda: smartd.collect(), None)

    report = {
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "snapshots": snap_summary,
        "alerts": {"total": len(alerts), "critical": crit, "warn": warn,
                   "items": [{"title": a.get("title"), "sev": a.get("sev")} for a in alerts]},
        "freeable": freeable,
        "disk": disk,
        "smart": smart,
        "summary": "",
    }
    report["summary"] = _summary_line(report)
    return report


def _snapshot_summary() -> dict:
    vols = storage.list_all_volumes()
    total = 0
    protected = 0
    latest = None
    for vol in vols:
        try:
            snaps = storage.list_all_snapshots(vol)
        except Exception:  # noqa: BLE001
            snaps = []
        total += len(snaps)
        if snaps:
            protected += 1
            dated = [s for s in snaps if getattr(s, "created_at", None)]
            lt = sorted(dated, key=lambda s: s.created_at)[-1].created_at if dated else snaps[-1].name
            if latest is None or lt > latest:
                latest = lt
    return {"volume_count": len(vols), "snapshot_count": total,
            "protected_volumes": protected, "latest_snapshot": latest}


# 以下文案统一用大白话，避免「快照/告警/可释放空间/硬盘健康」等术语直接推到用户眼前


def _freeable_summary() -> dict:
    rpt = junk.load_report()
    if not rpt or not rpt.get("categories"):
        return {"scanned": False, "total_bytes": 0, "categories": []}
    cats = []
    total = 0
    for c in rpt["categories"]:
        if c.get("key") == "docker":
            continue  # Docker 可回收空间不计入「可立即清理」字节数
        b = c.get("total_bytes", 0)
        n = len(c.get("items", []))
        if b <= 0 and n == 0:
            continue
        total += b
        cats.append({"key": c["key"], "name": c["name"], "bytes": b, "items": n})
    return {"scanned": True, "total_bytes": total, "categories": cats,
            "scanned_at": rpt.get("scanned_at")}


def _disk_summary() -> dict:
    m = metrics.collect(force=True)
    vols = m.get("volumes") or []
    # 与网页/看门狗同一套容量判据，日报不再自己按 75% 拍脑袋
    alerts = metrics.space_alerts(vols, m.get("trends") or [])
    tight = [{"mount": a.get("mount"), "percent": a.get("percent"), "free_gb": a.get("free_gb")}
             for a in alerts if a.get("kind") == "vol"]
    trends = [{"mount": a.get("mount"), "days_to_full": a.get("days"), "percent": a.get("percent")}
              for a in alerts if a.get("kind") == "trend"]
    disks = m.get("disks") or []
    hot = [{"name": d.get("name"), "temp_c": d.get("temp_c")}
           for d in disks if d.get("temp_c") is not None and d["temp_c"] >= 50]
    return {
        "hostname": m.get("hostname"),
        "cpu_temp": (m.get("cpu") or {}).get("temp_c"),
        "volume_count": len(vols),
        "tight_volumes": tight,
        "days_to_full": trends,
        "hot_disks": hot,
    }


def _summary_line(r: dict) -> str:
    parts = []
    snap = r.get("snapshots")
    if snap:
        if snap.get("protected_volumes"):
            parts.append(f"{snap['protected_volumes']} 个盘已保护、共 {snap['snapshot_count']} 个备份点")
        else:
            parts.append("还没给任何盘建备份点（建议立即建一个）")
    al = r.get("alerts") or {}
    if al.get("total"):
        parts.append(f"{al['critical']} 项严重、{al['warn']} 项需要注意")
    else:
        parts.append("没有新异常")
    fb = r.get("freeable")
    if fb and fb.get("scanned"):
        if fb.get("total_bytes"):
            parts.append(f"能清理出 {_fmt_bytes(fb['total_bytes'])}")
        else:
            parts.append("没有能清理的空间")
    else:
        parts.append("还没扫过垃圾（去「磁盘清理」扫一次就有数字）")
    return "；".join(parts) + "。"


def _fmt_bytes(n) -> str:
    n = float(n or 0)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB":
            return f"{n:.1f} {u}" if u != "B" else f"{int(n)} B"
        n /= 1024
    return f"{n:.1f} TB"


def format_text(report: dict) -> str:
    """把结构化报告压成一条适合推送的纯文本卡片。"""
    lines = ["📋 NAS Safe 每日状态", f"⏰ {report.get('generated_at','')}", ""]
    snap = report.get("snapshots") or {}
    lines.append("【备份情况】")
    if snap:
        lines.append(f"  · 共 {snap.get('volume_count')} 个盘，{snap.get('protected_volumes')} 个已保护")
        lines.append(f"  · 备份点共 {snap.get('snapshot_count')} 个，最新：{snap.get('latest_snapshot') or '无'}")
    else:
        lines.append("  · 数据暂不可用")

    al = report.get("alerts") or {}
    lines.append("【异常提醒】")
    if al.get("total"):
        lines.append(f"  · 共 {al['total']} 项（严重 {al['critical']} / 需要注意 {al['warn']}）")
        for it in (al.get("items") or [])[:5]:
            icon = "🔴" if it.get("sev") == 2 else "🟠"
            lines.append(f"    {icon} {it.get('title')}")
    else:
        lines.append("  · 没有新异常 ✓")

    fb = report.get("freeable")
    lines.append("【能清理的空间】")
    if fb and fb.get("scanned"):
        if fb.get("total_bytes"):
            lines.append(f"  · 能清出 {_fmt_bytes(fb['total_bytes'])}")
            for c in fb.get("categories") or []:
                lines.append(f"    - {c['name']}：{c['items']} 项 / {_fmt_bytes(c['bytes'])}")
        else:
            lines.append("  · 没有能清理的空间")
    else:
        lines.append("  · 还没扫过垃圾（建议去「磁盘清理」扫一次）")

    dk = report.get("disk") or {}
    lines.append("【硬盘状态】")
    # SMART 健康（跨品牌；群晖/绿联/通用 Linux 开箱即用，威联通装免费 Smartmontools 即开）
    smart = report.get("smart") or {}
    if smart.get("available"):
        lines.append(f"  · SMART 健康：{smart.get('health_label')}（共 {smart.get('disk_count')} 块盘）")
        for d in (smart.get("disks") or []):
            if d.get("health") == "fail":
                lines.append(f"    🔴 盘 {d['name']} 异常（出现过坏道，建议尽快备份并换盘）")
            elif d.get("health") == "warn":
                lines.append(f"    ⚠️ 盘 {d['name']} 需注意（出现过坏道苗头，留意）")
    elif smart:
        lines.append("  · SMART：暂未开启（威联通请在应用中心装免费的 Smartmontools 即可）")
    if dk:
        if dk.get("cpu_temp") is not None:
            lines.append(f"  · CPU 温度 {dk['cpu_temp']}°C")
        if dk.get("hot_disks"):
            for h in dk["hot_disks"][:4]:
                lines.append(f"  · 磁盘 {h['name']} 温度 {h['temp_c']}°C")
        if dk.get("tight_volumes"):
            for v in dk["tight_volumes"][:4]:
                lines.append(f"  · 盘 {v['mount']} 已用 {v['percent']}%")
        if dk.get("days_to_full"):
            for t in dk["days_to_full"][:3]:
                lines.append(f"  · 盘 {t['mount']} 约 {t['days_to_full']} 天后会满")
        if not (dk.get("cpu_temp") is not None or dk.get("hot_disks")
                or dk.get("tight_volumes") or dk.get("days_to_full")):
            lines.append("  · 各项指标正常 ✓")
    else:
        lines.append("  · 数据暂不可用")

    lines.append("")
    lines.append("一句话：" + (report.get("summary") or ""))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 发送（复用 notify 通道，零新增权限）
# ---------------------------------------------------------------------------

def send_daily() -> dict:
    """生成报告 → 推送到已启用通道 → 存最近一次报告。返回结果。"""
    report = build_report()
    text = format_text(report)
    cfg = load_config()
    sent = {"enabled": cfg.get("enabled", False), "sent": [], "skipped": "通知未启用" if not cfg.get("enabled") else ""}
    if cfg.get("enabled"):
        # 复用 notify.dispatch：把日报作为「事件」推送，自动走所有已启用通道
        sent = notify.dispatch(
            alerts=[],
            events=[{"title": "NAS Safe 每日状态", "detail": text}],
        )
    last = {"report": report, "text": text, "sent_at": report.get("generated_at"), "dispatch": sent}
    save_last(last)
    return last


# ---------------------------------------------------------------------------
# 定时调度（后台守护线程）
# ---------------------------------------------------------------------------

def start_scheduler() -> "threading.Thread":
    """后台守护线程：每天在用户设定的 hour:minute 推送日报。"""
    def _next_target(cfg: dict) -> float:
        lt = time.localtime()
        y, mo, d = lt.tm_year, lt.tm_mon, lt.tm_mday
        # 今天的目标时刻；已过则顺延到明天
        t = time.mktime((y, mo, d, cfg.get("hour", 8), cfg.get("minute", 0), 0, 0, 0, -1))
        if t <= time.time() + 30:
            t += 86400
        return t

    def _loop() -> None:
        while True:
            try:
                cfg = load_config()
                if cfg.get("enabled"):
                    wait = _next_target(cfg) - time.time()
                    if wait > 0:
                        # 最多睡 1 小时再检查（用户可能改了时间/开关），到点前不发送
                        time.sleep(min(wait, 3600))
                        continue
                    try:
                        send_daily()
                    except Exception:  # noqa: BLE001
                        pass
            except Exception:  # noqa: BLE001
                pass
            time.sleep(300)  # 兜底轮询间隔

    t = threading.Thread(target=_loop, daemon=True)
    t.start()
    return t
